def task_checker():
    return {'actions': ["pychecker sample.py"],
            'dependencies': ["sample.py"]}
