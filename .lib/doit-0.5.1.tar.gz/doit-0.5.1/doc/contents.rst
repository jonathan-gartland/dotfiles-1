.. doit documentation master file, created by
   sphinx-quickstart on Fri Apr 10 08:21:39 2009.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

`doit` documentation
====================

Contents:

.. toctree::
   :maxdepth: 2

   install
   tasks
   dependencies
   env_setup
   cmd_run
   cmd_other
   tools
   reference
   faq
   changes
   developer
   related
