
def task_xxx1():
    """task doc"""
    return {'actions':['do nothing']}

def task_yyy2():
    return {'actions':None}

def bad_seed():
    pass
